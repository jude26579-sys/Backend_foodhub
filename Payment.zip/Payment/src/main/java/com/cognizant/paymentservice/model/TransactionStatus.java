package com.cognizant.paymentservice.model;

public enum TransactionStatus {
    SUCCESS,
    FAILED,
    REFUNDED
}
