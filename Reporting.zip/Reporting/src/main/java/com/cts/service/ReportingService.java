package com.cts.service;

import java.time.LocalDate;
import java.util.List;

import com.cts.dtos.OverallReportDto;
import com.cts.entities.ReportRequest;

public interface ReportingService {
	List<OverallReportDto> getAllReports();
	OverallReportDto getReportById(String reportId);
	OverallReportDto addReport(ReportRequest reportRequest);
	//List<OverallReportDto> searchReportsByDateRange(LocalDate start, LocalDate end);
	void deleteReportById(String reportId);
}
