package com.cts.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.cts.clients.ReportingClient;
import com.cts.dtos.OrderReportEntryDto;
import com.cts.dtos.OverallReportDto;
import com.cts.dtos.RestaurantReportDto;
import com.cts.entities.Duration;
import com.cts.entities.OrderReportEntry;
import com.cts.entities.OverallReport;
import com.cts.entities.ReportRequest;
import com.cts.entities.RestaurantReport;
import com.cts.repository.ReportRepository;

import jakarta.transaction.Transactional;

@Service
public class ReportingServiceImpl implements ReportingService {
	private ReportRepository reportRepository;
	private ReportingClient reportingClient;
	
	public ReportingServiceImpl(ReportRepository reportRepository, ReportingClient reportingClient) {
		super();
		this.reportRepository = reportRepository;
		this.reportingClient = reportingClient;
	}

	@Override
	public List<OverallReportDto> getAllReports() {
	    List<OverallReport> reports = reportRepository.findAll();

	    return reports.stream().map(report -> {
	        OverallReportDto dto = new OverallReportDto();
	        dto.setReportId(report.getReportId());
	        dto.setDuration(report.getDuration());
	        dto.setTotalSales(report.getTotalSales());
	        dto.setRestaurantCount(report.getRestaurantCount());
	        dto.setOrderCount(report.getOrderCount());
	        dto.setReportGeneratedAt(report.getReportGeneratedAt());

	        List<RestaurantReportDto> restaurantDtos = report.getRestaurants().stream().map(restaurant -> {
	            List<OrderReportEntryDto> orderDtos = restaurant.getOrders().stream().map(order -> {
	                OrderReportEntryDto orderDto = new OrderReportEntryDto();
	                orderDto.setOrderId(order.getOrderId());
	                orderDto.setOrderSalesAmt(order.getOrderSalesAmt());
	                orderDto.setOrderStatus(order.getOrderStatus());
	                orderDto.setCreatedAt(order.getCreatedAt());
	                return orderDto;
	            }).toList();

	            RestaurantReportDto restaurantDto = new RestaurantReportDto();
	            restaurantDto.setRestaurantId(restaurant.getRestaurantId());
	            restaurantDto.setRestaurantOrderCount(restaurant.getRestaurantOrderCount());
	            restaurantDto.setOrders(orderDtos);
	            return restaurantDto;
	        }).toList();

	        dto.setRestaurants(restaurantDtos);
	        return dto;
	    }).toList();
	}

	@Override
	public OverallReportDto getReportById(String reportId) {
	    OverallReport report = reportRepository.findByReportId(reportId);

	    if (report == null) {
	        return null; // or throw a custom NotFoundException
	    }

	    OverallReportDto dto = new OverallReportDto();
	    dto.setReportId(report.getReportId());
	    dto.setDuration(report.getDuration());
	    dto.setTotalSales(report.getTotalSales());
	    dto.setRestaurantCount(report.getRestaurantCount());
	    dto.setOrderCount(report.getOrderCount());
	    dto.setReportGeneratedAt(report.getReportGeneratedAt());

	    List<RestaurantReportDto> restaurantDtos = report.getRestaurants().stream().map(restaurant -> {
	        List<OrderReportEntryDto> orderDtos = restaurant.getOrders().stream().map(order -> {
	            OrderReportEntryDto orderDto = new OrderReportEntryDto();
	            orderDto.setOrderId(order.getOrderId());
	            orderDto.setOrderSalesAmt(order.getOrderSalesAmt());
	            orderDto.setOrderStatus(order.getOrderStatus());
	            orderDto.setCreatedAt(order.getCreatedAt());
	            return orderDto;
	        }).toList();

	        RestaurantReportDto restaurantDto = new RestaurantReportDto();
	        restaurantDto.setRestaurantId(restaurant.getRestaurantId());
	        restaurantDto.setRestaurantOrderCount(restaurant.getRestaurantOrderCount());
	        restaurantDto.setOrders(orderDtos);
	        return restaurantDto;
	    }).toList();

	    dto.setRestaurants(restaurantDtos);
	    return dto;
	}

	@Override
	public OverallReportDto addReport(ReportRequest reportRequest) {
	    List<Map<String, Object>> rawOrders = reportingClient.getOrdersByDateAndRestaurantIds(
	        reportRequest.getStartDate().toString(),
	        reportRequest.getEndDate().toString(),
	        reportRequest.getRestaurantIds()
	    );

	    Map<Long, List<OrderReportEntry>> ordersByRestaurant = new HashMap<>();
	    double totalSales = 0;
	    int totalOrders = 0;

	    for (Map<String, Object> rawOrder : rawOrders) {
	        try {
	            String status = rawOrder.get("orderStatus") != null
	                ? rawOrder.get("orderStatus").toString()
	                : null;

	            if (!"PAYMENT_SUCCESS".equalsIgnoreCase(status)) {
	                continue;
	            }

	            Long restaurantId = rawOrder.get("restaurantId") != null
	                ? Long.valueOf(rawOrder.get("restaurantId").toString())
	                : null;
	            Long orderId = rawOrder.get("orderId") != null
	                ? Long.valueOf(rawOrder.get("orderId").toString())
	                : null;

	            Double subTotal = 0.0;
	            Object subTotalObj = rawOrder.get("subTotal");
	            if (subTotalObj != null && !subTotalObj.toString().isBlank()) {
	                try {
	                    subTotal = Double.parseDouble(subTotalObj.toString());
	                } catch (NumberFormatException e) {
	                    System.out.println("Invalid subTotal for orderId " + orderId + ": " + subTotalObj);
	                    subTotal = 0.0;
	                }
	            }

	            LocalDateTime createdAt = rawOrder.get("createdAt") != null
	                ? LocalDateTime.parse(rawOrder.get("createdAt").toString())
	                : LocalDateTime.now();

	            if (restaurantId == null || orderId == null) continue;
	            
	            if (!reportRequest.getRestaurantIds().contains(restaurantId)) continue;
	            
	            OrderReportEntry entry = new OrderReportEntry();
	            entry.setOrderId(orderId);
	            entry.setOrderSalesAmt(subTotal); // use subTotal here
	            entry.setOrderStatus(status);
	            entry.setCreatedAt(createdAt);

	            ordersByRestaurant.computeIfAbsent(restaurantId, k -> new ArrayList<>()).add(entry);
	            totalSales += subTotal;
	            totalOrders++;
	        } catch (Exception e) {
	            System.out.println("Skipping malformed order: " + rawOrder);
	            continue;
	        }
	    }

	    OverallReport overallReport = new OverallReport();
	    String reportId = "REP-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
	    overallReport.setReportId(reportId);
	    overallReport.setDuration(new Duration(reportRequest.getStartDate(), reportRequest.getEndDate()));
	    overallReport.setTotalSales(totalSales);
	    overallReport.setRestaurantCount(reportRequest.getRestaurantIds().size());
	    overallReport.setOrderCount(totalOrders);
	    overallReport.setReportGeneratedAt(LocalDateTime.now());

	    List<RestaurantReport> restaurantReports = new ArrayList<>();
	    for (Long restaurantId : reportRequest.getRestaurantIds()) {
	        List<OrderReportEntry> orders = ordersByRestaurant.getOrDefault(restaurantId, List.of());

	        RestaurantReport restaurantReport = new RestaurantReport();
	        restaurantReport.setRestaurantId(restaurantId);
	        restaurantReport.setRestaurantOrderCount(orders.size());
	        restaurantReport.setOverallReport(overallReport);

	        for (OrderReportEntry order : orders) {
	            order.setRestaurantReport(restaurantReport);
	        }

	        restaurantReport.setOrders(orders);
	        restaurantReports.add(restaurantReport);
	    }

	    overallReport.setRestaurants(restaurantReports);
	    OverallReport savedReport = reportRepository.save(overallReport);

	    // Convert to DTO
	    OverallReportDto reportDto = new OverallReportDto();
	    reportDto.setReportId(savedReport.getReportId());
	    reportDto.setDuration(savedReport.getDuration());
	    reportDto.setTotalSales(savedReport.getTotalSales());
	    reportDto.setRestaurantCount(savedReport.getRestaurantCount());
	    reportDto.setOrderCount(savedReport.getOrderCount());
	    reportDto.setReportGeneratedAt(savedReport.getReportGeneratedAt());

	    List<RestaurantReportDto> restaurantDtos = savedReport.getRestaurants().stream().map(restaurant -> {
	        List<OrderReportEntryDto> orderDtos = restaurant.getOrders().stream().map(order -> {
	            OrderReportEntryDto dto = new OrderReportEntryDto();
	            dto.setOrderId(order.getOrderId());
	            dto.setOrderSalesAmt(order.getOrderSalesAmt());
	            dto.setOrderStatus(order.getOrderStatus());
	            dto.setCreatedAt(order.getCreatedAt());
	            return dto;
	        }).toList();

	        RestaurantReportDto restaurantDto = new RestaurantReportDto();
	        restaurantDto.setRestaurantId(restaurant.getRestaurantId());
	        restaurantDto.setRestaurantOrderCount(restaurant.getRestaurantOrderCount());
	        restaurantDto.setOrders(orderDtos);
	        return restaurantDto;
	    }).toList();

	    reportDto.setRestaurants(restaurantDtos);

	    return reportDto;
	}
	
	@Override
	@Transactional
	public void deleteReportById(String reportId) {
	    if (reportId == null || reportId.isBlank()) {
	        throw new IllegalArgumentException("reportId must not be null or blank.");
	    }

	    OverallReport report = reportRepository.findByReportId(reportId);
	    if (report != null) {
	        reportRepository.delete(report);
	    } 
	}

//	@Override
//	public List<OverallReportDto> searchReportsByDateRange(LocalDate start, LocalDate end) {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
