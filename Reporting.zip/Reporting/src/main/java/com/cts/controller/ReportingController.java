package com.cts.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.http.MediaType;
import org.springframework.http.HttpHeaders;

import com.cts.dtos.OverallReportDto;
import com.cts.entities.ReportRequest;
import com.cts.service.PdfService;
import com.cts.service.ReportingService;

@RestController
@RequestMapping("/api/report")
public class ReportingController {
	private ReportingService reportingService;
	private PdfService pdfService;
	
	public ReportingController(ReportingService reportingService, PdfService pdfService) {
		super();
		this.reportingService = reportingService;
		this.pdfService = pdfService;
	}
	
//	@GetMapping
//    public ResponseEntity<List<OverallReportDto>> getAllOrders() {
//        List<OverallReportDto> list = reportingService.getAllReports();
//        return ResponseEntity.ok(list);
//    }
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_PDF_VALUE})
	public ResponseEntity<?> getAllOrders(@RequestHeader("Accept") String acceptHeader) {
	    List<OverallReportDto> list = reportingService.getAllReports();

	    if (acceptHeader.equals(MediaType.APPLICATION_PDF_VALUE)) {
	        byte[] pdfBytes = pdfService.generateAllReportsPdf(list);
	        return ResponseEntity.ok()
	                .contentType(MediaType.APPLICATION_PDF)
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=all_reports.pdf")
	                .body(pdfBytes);
	    }

	    return ResponseEntity.ok(list);
	}
	
//	@GetMapping("/{reportId}")
//	public ResponseEntity<OverallReportDto> getReportById(@PathVariable String reportId) {
//        OverallReportDto dto = reportingService.getReportById(reportId);
//        if (dto == null) {
//            return ResponseEntity.notFound().build();
//        }
//        return ResponseEntity.ok(dto);
//    }
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping(value = "/{reportId}", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_PDF_VALUE})
	public ResponseEntity<?> getReportById(@PathVariable String reportId,
	                                       @RequestHeader("Accept") String acceptHeader) {
	    OverallReportDto dto = reportingService.getReportById(reportId);
	    if (dto == null) {
	        return ResponseEntity.notFound().build();
	    }

	    if (acceptHeader.equals(MediaType.APPLICATION_PDF_VALUE)) {
	        byte[] pdfBytes = pdfService.generateReportPdf(dto);
	        return ResponseEntity.ok()
	                .contentType(MediaType.APPLICATION_PDF)
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=report_" + reportId + ".pdf")
	                .body(pdfBytes);
	    }

	    return ResponseEntity.ok(dto);
	}
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping
    public ResponseEntity<OverallReportDto> addReport(@RequestBody ReportRequest dto) {
        OverallReportDto report = reportingService.addReport(dto);
        return ResponseEntity.ok(report);
    }
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/{reportId}")
	public ResponseEntity<Void> delete(@PathVariable String reportId) {
		reportingService.deleteReportById(reportId);
		return ResponseEntity.status(HttpStatus.ACCEPTED).build();
	}
	

//	@GetMapping("/search-by-date")
//	public ResponseEntity<List<OverallReportDto>> searchReportsByDateRange(
//	        @RequestParam("start") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate start,
//	        @RequestParam("end") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate end) {
//
//	    List<OverallReportDto> reports = reportingService.searchReportsByDateRange(start, end);
//	    return ResponseEntity.ok(reports);
//	}



}
