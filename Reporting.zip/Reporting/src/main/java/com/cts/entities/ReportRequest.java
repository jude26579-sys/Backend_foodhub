package com.cts.entities;

import java.time.LocalDate;
import java.util.List;


public class ReportRequest {
    private LocalDate startDate;
    private LocalDate endDate;
    private List<Long> restaurantIds;
    
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public List<Long> getRestaurantIds() {
		return restaurantIds;
	}
	public void setRestaurantIds(List<Long> restaurantIds) {
		this.restaurantIds = restaurantIds;
	}
}
