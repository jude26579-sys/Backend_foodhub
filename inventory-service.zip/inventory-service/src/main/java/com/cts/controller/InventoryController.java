package com.cts.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dto.InventoryDto;
import com.cts.dto.InventoryUpdateRequest;
import com.cts.service.InventoryService;
import com.cts.validation.Validation.Create;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {
	@Autowired
public InventoryService inventoryservice;
	@PreAuthorize("hasAnyRole('VENDOR','CUSTOMER')")
	@GetMapping("/{id}")
	public ResponseEntity<List<InventoryDto>> getAll(@PathVariable Long id){
		List<InventoryDto> inventory=inventoryservice.getIventory(id);
		return ResponseEntity.ok(inventory);
	}
	@PreAuthorize("hasAnyRole('VENDOR','CUSTOMER')")
	@PostMapping
	public ResponseEntity<InventoryDto> create( @Validated(Create.class) @RequestBody InventoryDto dto){
		InventoryDto created=inventoryservice.addInventory(dto);
		return new ResponseEntity<InventoryDto>(created,HttpStatus.CREATED);	
	}
	@PreAuthorize("hasAnyRole('VENDOR','CUSTOMER')")
@PutMapping("/{id}")
    public ResponseEntity<InventoryDto> updateInventory(@PathVariable Long id,@RequestBody InventoryDto dto) {
        InventoryDto updated = inventoryservice.updateInventory(dto);
        return ResponseEntity.ok(updated);
    }
	@PreAuthorize("hasAnyRole('VENDOR','CUSTOMER')")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteInventory(@PathVariable Long id) {
        inventoryservice.deleteInventory(id);
        return ResponseEntity.ok("Inventory deleted successfully");
    }
	@PreAuthorize("hasAnyRole('VENDOR','CUSTOMER')")
	 @PutMapping("/update")
	    public ResponseEntity<Void> updateInventory(@RequestBody InventoryUpdateRequest request) {
	        inventoryservice.updateInventory(request);
	        return ResponseEntity.ok().build();
	    }
}



