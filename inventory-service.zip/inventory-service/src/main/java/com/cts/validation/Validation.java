package com.cts.validation;

public class Validation {
	public interface Create{}
	public interface Update{}
}
