package com.cts.service;

import java.util.List;

import com.cts.dto.InventoryDto;
import com.cts.dto.InventoryUpdateRequest;

public interface InventoryService {
		List<InventoryDto> getIventory(Long id);
		InventoryDto addInventory(InventoryDto dto);
		InventoryDto updateInventory(InventoryDto dto);
		void deleteInventory(Long id);
		//void reduceInventoryAfterOrder(Long restaurantId, Long categoryId, Long itemId, int quantityOrdered);
		void updateInventory(InventoryUpdateRequest req);
		
}
