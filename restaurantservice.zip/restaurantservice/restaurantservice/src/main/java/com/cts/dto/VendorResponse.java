package com.cts.dto;

public class VendorResponse {
	private Long id;
	private String name;
	private String email;

}
