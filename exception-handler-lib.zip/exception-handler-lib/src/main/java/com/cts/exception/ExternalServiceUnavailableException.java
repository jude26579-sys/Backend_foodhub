package com.cts.exception;

public class ExternalServiceUnavailableException extends RuntimeException {

	public ExternalServiceUnavailableException(String message) {
		super(message);
	}
	

}
